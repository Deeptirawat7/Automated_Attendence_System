# Automated Attendance System using Face Recognition

A Flask web application for registering students, training face encodings, taking webcam-based attendance, viewing records, and exporting CSV reports.

## Features

- Separate teacher and student logins with hashed password storage
- Student registration with multiple webcam images
- Student self-attendance and attendance percentage view
- Student deletion from the teacher dashboard with saved face data cleanup
- OpenCV face detection and `face_recognition` matching
- Automatic attendance marking with name, date, and time
- Duplicate attendance prevention for the same student on the same day
- SQLite database storage
- Filterable attendance records
- CSV export using Pandas when available
- Dark mode, success messages, sound notification, and live bounding boxes

## Folder Structure

```text
.
├── app.py
├── database/
│   └── data.db
├── requirements.txt
├── dataset/
├── encodings/
├── static/
│   ├── css/
│   │   └── style.css
│   └── js/
│       ├── app.js
│       └── student.js
└── templates/
    ├── index.html
    ├── login.html
    ├── dashboard.html
    └── student_dashboard.html
```

## Local Setup

1. Create and activate a virtual environment:

```powershell
python -m venv venv
.\venv\Scripts\Activate.ps1
```

2. Install dependencies:

```powershell
python -m pip install --upgrade pip
pip install -r requirements.txt
```

3. Run the Flask app:

```powershell
python app.py
```

4. Open the app:

```text
http://127.0.0.1:5000
```

Default teacher credentials:

```text
Username: admin
Password: admin123
```

Student credentials are created by the teacher when registering a student. Existing students migrated from an older database can log in with their Student ID and this default password:

```text
Password: student123
```

## Import Database SQL

The file `database_schema.sql` contains the SQLite table structure and default teacher user.

Using the SQLite command line:

```powershell
sqlite3 database\data.db ".read database_schema.sql"
```

Using DB Browser for SQLite:

1. Open DB Browser for SQLite.
2. Click `Open Database` and select `database/data.db`, or create a new database file with that path.
3. Go to `File > Import > Database from SQL file`.
4. Select `database_schema.sql`.
5. Click `Write Changes`.

## Quit the Project

If the Flask app is running in the terminal, press:

```text
Ctrl + C
```

Then deactivate the virtual environment:

```powershell
deactivate
```

## Troubleshooting Registration

If registration says OpenCV, NumPy, or `face_recognition` must be installed, first make sure the virtual environment is active and dependencies are installed:

```powershell
.\venv\Scripts\Activate.ps1
pip install -r requirements.txt
python app.py
```

This project also copies `face_recognition` model files to an AppData cache on Windows so `dlib` can load them even when the project path contains non-English characters. Restart Flask after installing packages or changing code.

For a real deployment, set these before the first database initialization:

```powershell
$env:TEACHER_USERNAME="your_teacher_name"
$env:TEACHER_PASSWORD="your_strong_password"
$env:STUDENT_DEFAULT_PASSWORD="temporary_student_password"
$env:SECRET_KEY="a-long-random-secret"
```

## Functional Flow

1. Teacher logs in.
2. Teacher registers a student, sets a student login password, and captures at least 3 face images.
3. The backend stores images in `dataset/` and saves encodings in `encodings/face_encodings.pkl`.
4. Student logs in with Student ID and password.
5. Student starts attendance from the student portal.
6. Flask detects the logged-in student's face and stores attendance in SQLite.
7. Student can see their attendance percentage.
8. Teacher can view records, train/retrain data, and export reports.

The student percentage is calculated as present days divided by class days. A class day is any distinct attendance date recorded in the system after that student was registered.

## API Endpoints

- `GET /api/status`
- `GET /api/students`
- `DELETE /api/students/<student_id>`
- `POST /api/register-student`
- `POST /api/retrain`
- `POST /api/recognize`
- `GET /api/attendance?date=YYYY-MM-DD&student=query`
- `GET /api/student/summary`
- `GET /api/export?date=YYYY-MM-DD&student=query`

Teacher-only APIs require teacher login. `/api/recognize` works for teachers and students; when a student is logged in, it only matches that student's trained face data.

## Notes for Face Recognition Setup

The `face-recognition` package depends on `dlib`. On Windows, installation may require:

- CMake
- Visual C++ Build Tools
- A Python version supported by available `dlib` wheels

If installation is difficult on Windows, use Python 3.10 or 3.11 and install a compatible prebuilt `dlib` wheel before running `pip install face-recognition`.

## Deployment

Render or Railway can run the app with these settings:

```text
Build command: pip install -r requirements.txt
Start command: gunicorn app:app
```

Camera access works on `localhost` during development. In production, browsers require HTTPS for webcam access.
