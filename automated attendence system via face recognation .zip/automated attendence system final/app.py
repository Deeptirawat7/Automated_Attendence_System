import base64
import io
import os
import pickle
import shutil
import sqlite3
import subprocess
import sys
from datetime import datetime
from functools import wraps
from pathlib import Path


def restart_with_project_venv():
    """Run through the bundled virtualenv when plain python is used."""
    if os.environ.get("ATTENDANCE_VENV_REEXEC") == "1":
        return

    base_dir = Path(__file__).resolve().parent
    venv_python = base_dir / "venv" / "Scripts" / "python.exe"
    if not venv_python.exists():
        venv_python = base_dir / "venv" / "bin" / "python"

    if not venv_python.exists():
        return

    try:
        current_python = Path(sys.executable).resolve()
        project_python = venv_python.resolve()
    except OSError:
        return

    if current_python != project_python:
        env = os.environ.copy()
        env["ATTENDANCE_VENV_REEXEC"] = "1"
        sys.exit(
            subprocess.call(
                [str(project_python), str(Path(__file__).resolve()), *sys.argv[1:]],
                env=env,
            )
        )


if __name__ == "__main__":
    restart_with_project_venv()

from flask import (
    Flask,
    Response,
    flash,
    jsonify,
    redirect,
    render_template,
    request,
    session,
    url_for,
)
from werkzeug.security import check_password_hash, generate_password_hash
from werkzeug.utils import secure_filename

try:
    import cv2
except Exception:  # pragma: no cover - shown in the UI/API when missing
    cv2 = None

face_recognition = None

try:
    import numpy as np
except Exception:  # pragma: no cover - shown in the UI/API when missing
    np = None

try:
    import pandas as pd
except Exception:  # pragma: no cover - CSV export falls back to stdlib
    pd = None


BASE_DIR = Path(__file__).resolve().parent
DATASET_DIR = BASE_DIR / "dataset"
ENCODINGS_DIR = BASE_DIR / "encodings"
ENCODINGS_FILE = ENCODINGS_DIR / "face_encodings.pkl"
DATABASE_DIR = BASE_DIR / "database"
DATABASE = DATABASE_DIR / "data.db"
VISION_IMPORT_ERROR = None

ALLOWED_IMAGE_EXTENSIONS = {".jpg", ".jpeg", ".png"}
MIN_REGISTRATION_IMAGES = 3
MAX_REGISTRATION_IMAGES = 5
REGISTRATION_DETECTION_WIDTH = 640
REGISTRATION_JPEG_QUALITY = 82
DEFAULT_TEACHER_USERNAME = os.getenv("TEACHER_USERNAME", os.getenv("ADMIN_USERNAME", "admin"))
DEFAULT_TEACHER_PASSWORD = os.getenv("TEACHER_PASSWORD", os.getenv("ADMIN_PASSWORD", "admin123"))
DEFAULT_ADMIN_USERNAME = DEFAULT_TEACHER_USERNAME
DEFAULT_ADMIN_PASSWORD = DEFAULT_TEACHER_PASSWORD
DEFAULT_STUDENT_PASSWORD = os.getenv("STUDENT_DEFAULT_PASSWORD", "student123")

app = Flask(__name__)
app.secret_key = os.getenv("SECRET_KEY", "change-this-secret-key-before-deployment")


def load_face_recognition_library():
    """
    Load face_recognition after moving dlib model files to an ASCII-only cache path.

    On Windows, dlib can fail to open model files when the project path contains
    non-ASCII characters. This workspace path contains Japanese characters, so the
    cache avoids that issue without asking the user to move the project.
    """
    import face_recognition_models

    cache_root = Path(
        os.getenv("LOCALAPPDATA", str(Path.home()))
    ) / "AutomatedAttendanceFaceModels"
    cache_root.mkdir(parents=True, exist_ok=True)

    model_functions = {
        "pose_predictor_model_location": "shape_predictor_68_face_landmarks.dat",
        "pose_predictor_five_point_model_location": "shape_predictor_5_face_landmarks.dat",
        "face_recognition_model_location": "dlib_face_recognition_resnet_model_v1.dat",
        "cnn_face_detector_model_location": "mmod_human_face_detector.dat",
    }

    cached_paths = {}
    for function_name, filename in model_functions.items():
        source = Path(getattr(face_recognition_models, function_name)())
        target = cache_root / filename

        if not target.exists() or target.stat().st_size != source.stat().st_size:
            shutil.copy2(source, target)

        cached_paths[function_name] = str(target)

    face_recognition_models.pose_predictor_model_location = (
        lambda path=cached_paths["pose_predictor_model_location"]: path
    )
    face_recognition_models.pose_predictor_five_point_model_location = (
        lambda path=cached_paths["pose_predictor_five_point_model_location"]: path
    )
    face_recognition_models.face_recognition_model_location = (
        lambda path=cached_paths["face_recognition_model_location"]: path
    )
    face_recognition_models.cnn_face_detector_model_location = (
        lambda path=cached_paths["cnn_face_detector_model_location"]: path
    )

    import face_recognition as loaded_face_recognition

    return loaded_face_recognition


try:
    face_recognition = load_face_recognition_library()
except Exception as error:  # pragma: no cover - shown in the UI/API when missing
    VISION_IMPORT_ERROR = str(error)


def ensure_project_folders():
    """Create folders used for uploaded faces and trained encodings."""
    DATABASE_DIR.mkdir(exist_ok=True)
    DATASET_DIR.mkdir(exist_ok=True)
    ENCODINGS_DIR.mkdir(exist_ok=True)


def get_db_connection():
    """Open a SQLite connection with dictionary-like rows."""
    conn = sqlite3.connect(DATABASE)
    conn.row_factory = sqlite3.Row
    return conn


def table_columns(conn, table_name):
    """Return existing column names for one of this app's SQLite tables."""
    return {row["name"] for row in conn.execute(f"PRAGMA table_info({table_name})")}


def ensure_column(conn, table_name, column_name, definition):
    """Add a column when an older database file does not have it yet."""
    if column_name not in table_columns(conn, table_name):
        conn.execute(f"ALTER TABLE {table_name} ADD COLUMN {column_name} {definition}")


def init_database():
    """Create database tables and a default teacher account."""
    ensure_project_folders()
    conn = get_db_connection()
    conn.execute(
        """
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT UNIQUE NOT NULL,
            password_hash TEXT NOT NULL,
            role TEXT NOT NULL DEFAULT 'teacher'
        )
        """
    )
    conn.execute(
        """
        CREATE TABLE IF NOT EXISTS students (
            student_id TEXT PRIMARY KEY,
            name TEXT NOT NULL,
            password_hash TEXT,
            created_at TEXT NOT NULL
        )
        """
    )
    conn.execute(
        """
        CREATE TABLE IF NOT EXISTS attendance (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            student_id TEXT NOT NULL,
            name TEXT NOT NULL,
            date TEXT NOT NULL,
            time TEXT NOT NULL,
            created_at TEXT NOT NULL,
            UNIQUE(student_id, date)
        )
        """
    )

    ensure_column(conn, "users", "role", "TEXT NOT NULL DEFAULT 'teacher'")
    ensure_column(conn, "students", "password_hash", "TEXT")
    conn.execute("UPDATE users SET role = 'teacher' WHERE role IS NULL OR role = ''")
    conn.execute(
        "UPDATE students SET password_hash = ? WHERE password_hash IS NULL OR password_hash = ''",
        (generate_password_hash(DEFAULT_STUDENT_PASSWORD),),
    )

    admin = conn.execute(
        "SELECT id FROM users WHERE username = ?", (DEFAULT_TEACHER_USERNAME,)
    ).fetchone()
    if admin is None:
        conn.execute(
            "INSERT INTO users (username, password_hash, role) VALUES (?, ?, 'teacher')",
            (
                DEFAULT_TEACHER_USERNAME,
                generate_password_hash(DEFAULT_TEACHER_PASSWORD),
            ),
        )
    conn.commit()
    conn.close()


def current_user_role():
    """Read the logged-in role while keeping older sessions compatible."""
    if session.get("user_role"):
        return session["user_role"]
    if "admin_id" in session:
        return "teacher"
    if "student_id" in session:
        return "student"
    return None


def api_auth_response(message, status):
    return jsonify({"success": False, "message": message}), status


def student_account_exists(student_id):
    if not student_id:
        return False

    conn = get_db_connection()
    try:
        return (
            conn.execute(
                "SELECT 1 FROM students WHERE student_id = ?",
                (student_id,),
            ).fetchone()
            is not None
        )
    finally:
        conn.close()


def login_required(view):
    """Protect teacher pages and APIs from non-teacher users."""

    @wraps(view)
    def wrapped_view(*args, **kwargs):
        role = current_user_role()
        if role != "teacher":
            if request.path.startswith("/api/"):
                status = 401 if role is None else 403
                return api_auth_response("Teacher login required.", status)
            if role == "student":
                return redirect(url_for("student_dashboard"))
            return redirect(url_for("teacher_login"))
        return view(*args, **kwargs)

    return wrapped_view


def student_login_required(view):
    """Protect student-only pages and APIs."""

    @wraps(view)
    def wrapped_view(*args, **kwargs):
        role = current_user_role()
        if role != "student":
            if request.path.startswith("/api/"):
                status = 401 if role is None else 403
                return api_auth_response("Student login required.", status)
            if role == "teacher":
                return redirect(url_for("dashboard"))
            return redirect(url_for("student_login"))
        if not student_account_exists(session.get("student_id")):
            session.clear()
            if request.path.startswith("/api/"):
                return api_auth_response("Student account no longer exists.", 401)
            flash("Your student account no longer exists.", "error")
            return redirect(url_for("student_login"))
        return view(*args, **kwargs)

    return wrapped_view


def any_login_required(view):
    """Protect APIs that both teachers and students can use."""

    @wraps(view)
    def wrapped_view(*args, **kwargs):
        role = current_user_role()
        if role is None:
            if request.path.startswith("/api/"):
                return api_auth_response("Login required.", 401)
            return redirect(url_for("index"))
        if role == "student" and not student_account_exists(session.get("student_id")):
            session.clear()
            if request.path.startswith("/api/"):
                return api_auth_response("Student account no longer exists.", 401)
            flash("Your student account no longer exists.", "error")
            return redirect(url_for("student_login"))
        return view(*args, **kwargs)

    return wrapped_view


def vision_libraries_ready():
    """Return True only when the required computer vision packages loaded."""
    return cv2 is not None and face_recognition is not None and np is not None


def vision_error_response():
    detail = f" Details: {VISION_IMPORT_ERROR}" if VISION_IMPORT_ERROR else ""
    return (
        jsonify(
            {
                "success": False,
                "message": (
                    "OpenCV, NumPy, and face_recognition must be installed before "
                    f"using camera recognition features.{detail}"
                ),
            }
        ),
        503,
    )


def validate_student_id(student_id):
    """Keep IDs folder-safe and beginner-friendly."""
    return bool(student_id) and student_id.replace("-", "").replace("_", "").isalnum()


def student_folder(student_id):
    safe_id = secure_filename(student_id)
    return DATASET_DIR / safe_id


def decode_image_from_data_url(data_url):
    """Convert a browser canvas data URL into an OpenCV BGR image."""
    if not vision_libraries_ready():
        raise RuntimeError("Vision libraries are not installed.")

    if "," in data_url:
        _, encoded = data_url.split(",", 1)
    else:
        encoded = data_url

    image_bytes = base64.b64decode(encoded)
    image_array = np.frombuffer(image_bytes, dtype=np.uint8)
    image = cv2.imdecode(image_array, cv2.IMREAD_COLOR)
    if image is None:
        raise ValueError("Could not decode image data.")
    return image


def clamp_face_box(box, image_shape):
    """Keep a face box inside the image boundaries."""
    height, width = image_shape[:2]
    top, right, bottom, left = box
    return (
        max(0, int(top)),
        min(width, int(right)),
        min(height, int(bottom)),
        max(0, int(left)),
    )


def pad_face_box(box, image_shape, padding_ratio=0.22):
    """Give dlib a little room around OpenCV face boxes for better landmarks."""
    top, right, bottom, left = box
    box_width = right - left
    box_height = bottom - top
    pad_x = int(box_width * padding_ratio)
    pad_y = int(box_height * padding_ratio)
    return clamp_face_box(
        (top - pad_y, right + pad_x, bottom + pad_y, left - pad_x),
        image_shape,
    )


def box_area(box):
    top, right, bottom, left = box
    return max(0, bottom - top) * max(0, right - left)


def add_unique_box(boxes, candidate, image_shape):
    """Add a face box if it is not already represented by a similar box."""
    candidate = clamp_face_box(candidate, image_shape)
    if box_area(candidate) <= 0:
        return

    c_top, c_right, c_bottom, c_left = candidate
    c_area = box_area(candidate)

    for existing in boxes:
        e_top, e_right, e_bottom, e_left = existing
        i_left = max(c_left, e_left)
        i_top = max(c_top, e_top)
        i_right = min(c_right, e_right)
        i_bottom = min(c_bottom, e_bottom)
        intersection = box_area((i_top, i_right, i_bottom, i_left))
        if intersection / min(c_area, box_area(existing)) > 0.55:
            return

    boxes.append(candidate)


def scaled_image_for_detection(image_bgr, max_width=900):
    """Resize wide camera frames so HOG detection stays responsive."""
    height, width = image_bgr.shape[:2]
    if width <= max_width:
        return image_bgr, 1.0

    scale = max_width / width
    resized = cv2.resize(
        image_bgr,
        (max_width, int(height * scale)),
        interpolation=cv2.INTER_AREA,
    )
    return resized, scale


def unscale_box(box, scale):
    if scale == 1.0:
        return box
    top, right, bottom, left = box
    return (
        int(top / scale),
        int(right / scale),
        int(bottom / scale),
        int(left / scale),
    )


def detect_faces(image_bgr, thorough=False, max_width=900):
    """
    Detect faces with OpenCV and, when needed, face_recognition's HOG detector.

    Registration uses thorough mode because reliability matters more than speed.
    Attendance uses the faster path, then falls back only when OpenCV misses.
    """
    detection_image, scale = scaled_image_for_detection(image_bgr, max_width=max_width)
    gray = cv2.cvtColor(detection_image, cv2.COLOR_BGR2GRAY)
    gray = cv2.equalizeHist(gray)
    boxes = []

    cascade_names = ["haarcascade_frontalface_default.xml"]
    if thorough:
        cascade_names.extend(
            ["haarcascade_frontalface_alt2.xml", "haarcascade_profileface.xml"]
        )

    for cascade_name in cascade_names:
        cascade_path = cv2.data.haarcascades + cascade_name
        detector = cv2.CascadeClassifier(cascade_path)
        if detector.empty():
            continue

        faces = detector.detectMultiScale(
            gray,
            scaleFactor=1.07 if thorough else 1.1,
            minNeighbors=4 if thorough else 5,
            minSize=(45, 45) if thorough else (70, 70),
        )

        for x, y, w, h in faces:
            add_unique_box(
                boxes,
                unscale_box((y, x + w, y + h, x), scale),
                image_bgr.shape,
            )

        if thorough and cascade_name == "haarcascade_profileface.xml":
            flipped_gray = cv2.flip(gray, 1)
            flipped_faces = detector.detectMultiScale(
                flipped_gray,
                scaleFactor=1.07,
                minNeighbors=4,
                minSize=(45, 45),
            )
            flipped_width = flipped_gray.shape[1]
            for x, y, w, h in flipped_faces:
                original_x = flipped_width - x - w
                add_unique_box(
                    boxes,
                    unscale_box((y, original_x + w, y + h, original_x), scale),
                    image_bgr.shape,
                )

    if thorough or not boxes:
        image_rgb = cv2.cvtColor(detection_image, cv2.COLOR_BGR2RGB)
        hog_boxes = face_recognition.face_locations(
            image_rgb,
            number_of_times_to_upsample=2 if thorough else 1,
            model="hog",
        )
        for box in hog_boxes:
            add_unique_box(boxes, unscale_box(box, scale), image_bgr.shape)

    return sorted(boxes, key=box_area, reverse=True)


def largest_face_box(face_boxes):
    """Pick the largest detected face from one frame."""
    return max(
        face_boxes,
        key=lambda box: max(0, box[2] - box[0]) * max(0, box[1] - box[3]),
    )


def face_box_to_api(box):
    top, right, bottom, left = box
    return {
        "top": int(top),
        "left": int(left),
        "width": int(right - left),
        "height": int(bottom - top),
    }


def encode_face(image_bgr, face_box):
    """Create a numerical face encoding for a detected face."""
    image_rgb = cv2.cvtColor(image_bgr, cv2.COLOR_BGR2RGB)
    candidate_boxes = [
        pad_face_box(face_box, image_bgr.shape, 0.28),
        pad_face_box(face_box, image_bgr.shape, 0.16),
        clamp_face_box(face_box, image_bgr.shape),
    ]

    for candidate_box in candidate_boxes:
        encodings = face_recognition.face_encodings(
            image_rgb,
            [candidate_box],
            num_jitters=1,
            model="small",
        )
        if encodings:
            return encodings[0]

    return None


def best_face_encoding(image_bgr, face_boxes=None, run_fallback=True):
    """Find the first usable encoding from the strongest detected face boxes."""
    boxes = face_boxes if face_boxes is not None else detect_faces(image_bgr, thorough=True)

    for face_box in sorted(boxes, key=box_area, reverse=True):
        encoding = encode_face(image_bgr, face_box)
        if encoding is not None:
            return encoding, face_box

    if not run_fallback:
        return None, None

    image_rgb = cv2.cvtColor(image_bgr, cv2.COLOR_BGR2RGB)
    fallback_boxes = face_recognition.face_locations(
        image_rgb,
        number_of_times_to_upsample=2,
        model="hog",
    )
    for face_box in fallback_boxes:
        encoding = encode_face(image_bgr, face_box)
        if encoding is not None:
            return encoding, face_box

    return None, None


def load_known_encodings():
    """Load saved encodings from disk."""
    if not ENCODINGS_FILE.exists() or ENCODINGS_FILE.stat().st_size == 0:
        return []
    try:
        with ENCODINGS_FILE.open("rb") as file:
            records = pickle.load(file)
    except (OSError, EOFError, pickle.UnpicklingError, AttributeError, ValueError, TypeError):
        app.logger.warning("Saved face encodings could not be read; treating them as empty.")
        return []

    if not isinstance(records, list):
        app.logger.warning("Saved face encodings had an unexpected format; treating them as empty.")
        return []

    clean_records = [
        record
        for record in records
        if (
            isinstance(record, dict)
            and record.get("student_id")
            and record.get("name")
            and "encoding" in record
        )
    ]
    if len(clean_records) != len(records):
        app.logger.warning("Some saved face encoding records were invalid and were ignored.")

    return clean_records


def save_known_encodings(records):
    """Save trained encodings to disk."""
    ENCODINGS_DIR.mkdir(exist_ok=True)
    with ENCODINGS_FILE.open("wb") as file:
        pickle.dump(records, file)


def remove_student_encodings(student_id):
    """Remove one student's trained face encodings from disk."""
    known_records = load_known_encodings()
    filtered_records = [
        record
        for record in known_records
        if not isinstance(record, dict) or record.get("student_id") != student_id
    ]
    removed_count = len(known_records) - len(filtered_records)

    if removed_count:
        save_known_encodings(filtered_records)

    return removed_count


def active_known_encodings():
    """Return trained face records only for students still in the database."""
    known_records = load_known_encodings()
    if not known_records:
        return []

    conn = get_db_connection()
    try:
        active_students = {
            row["student_id"]: row["name"]
            for row in conn.execute("SELECT student_id, name FROM students")
        }
    finally:
        conn.close()

    return [
        {**record, "name": active_students[record["student_id"]]}
        for record in known_records
        if record["student_id"] in active_students
    ]


def remove_student_folder(student_id):
    """Delete saved face images for one student, keeping removal inside dataset/."""
    folder = student_folder(student_id)
    if not folder.exists():
        return False

    dataset_root = DATASET_DIR.resolve()
    target = folder.resolve()

    if target == dataset_root or dataset_root not in target.parents:
        raise RuntimeError("Unsafe student folder path.")

    shutil.rmtree(target)
    return True


def rebuild_encodings_from_dataset():
    """Train encodings for every image currently stored in the dataset folder."""
    if not vision_libraries_ready():
        raise RuntimeError("Vision libraries are not installed.")

    conn = get_db_connection()
    students = conn.execute("SELECT student_id, name FROM students ORDER BY name").fetchall()
    conn.close()

    trained_records = []
    skipped_images = 0

    for student in students:
        folder = student_folder(student["student_id"])
        if not folder.exists():
            continue

        for image_path in folder.iterdir():
            if image_path.suffix.lower() not in ALLOWED_IMAGE_EXTENSIONS:
                continue

            image_bgr = cv2.imread(str(image_path))
            if image_bgr is None:
                skipped_images += 1
                continue

            boxes = detect_faces(image_bgr, thorough=True)
            encoding, _ = best_face_encoding(image_bgr, boxes)
            if encoding is None:
                skipped_images += 1
                continue

            trained_records.append(
                {
                    "student_id": student["student_id"],
                    "name": student["name"],
                    "encoding": encoding,
                }
            )

    save_known_encodings(trained_records)
    return {"trained": len(trained_records), "skipped": skipped_images}


def mark_attendance(student_id, name):
    """Mark one attendance record per student per day."""
    now = datetime.now()
    date_value = now.strftime("%Y-%m-%d")
    time_value = now.strftime("%H:%M:%S")
    created_at = now.isoformat(timespec="seconds")

    conn = get_db_connection()
    try:
        conn.execute(
            """
            INSERT INTO attendance (student_id, name, date, time, created_at)
            VALUES (?, ?, ?, ?, ?)
            """,
            (student_id, name, date_value, time_value, created_at),
        )
        conn.commit()
        return {"marked": True, "date": date_value, "time": time_value}
    except sqlite3.IntegrityError:
        existing = conn.execute(
            """
            SELECT date, time FROM attendance
            WHERE student_id = ? AND date = ?
            """,
            (student_id, date_value),
        ).fetchone()
        return {
            "marked": False,
            "duplicate": True,
            "date": existing["date"],
            "time": existing["time"],
        }
    finally:
        conn.close()


def attendance_query(filters):
    """Build the attendance query used by the table and CSV export."""
    query = "SELECT id, student_id, name, date, time FROM attendance WHERE 1 = 1"
    params = []

    selected_date = filters.get("date", "").strip()
    student = filters.get("student", "").strip()

    if selected_date:
        query += " AND date = ?"
        params.append(selected_date)

    if student:
        query += " AND (student_id LIKE ? OR name LIKE ?)"
        params.extend([f"%{student}%", f"%{student}%"])

    query += " ORDER BY date DESC, time DESC"
    return query, params


def student_attendance_summary(student_id):
    """Build the attendance percentage shown to a logged-in student."""
    conn = get_db_connection()
    student = conn.execute(
        "SELECT student_id, name, created_at FROM students WHERE student_id = ?",
        (student_id,),
    ).fetchone()

    if student is None:
        conn.close()
        return None

    registered_date = (student["created_at"] or "").split("T", 1)[0]
    total_query = "SELECT COUNT(DISTINCT date) AS count FROM attendance"
    total_params = []
    if registered_date:
        total_query += " WHERE date >= ?"
        total_params.append(registered_date)

    total_days = conn.execute(total_query, total_params).fetchone()["count"] or 0
    present_query = """
        SELECT COUNT(DISTINCT date) AS count
        FROM attendance
        WHERE student_id = ?
    """
    present_params = [student_id]
    if registered_date:
        present_query += " AND date >= ?"
        present_params.append(registered_date)
    present_days = conn.execute(present_query, present_params).fetchone()["count"] or 0
    today = datetime.now().strftime("%Y-%m-%d")
    today_record = conn.execute(
        """
        SELECT date, time
        FROM attendance
        WHERE student_id = ? AND date = ?
        """,
        (student_id, today),
    ).fetchone()
    records = conn.execute(
        """
        SELECT id, student_id, name, date, time
        FROM attendance
        WHERE student_id = ?
        ORDER BY date DESC, time DESC
        """,
        (student_id,),
    ).fetchall()
    conn.close()

    percentage = round((present_days / total_days) * 100, 1) if total_days else 0
    return {
        "student": dict(student),
        "present_days": present_days,
        "total_days": total_days,
        "percentage": percentage,
        "today_marked": today_record is not None,
        "today_time": today_record["time"] if today_record else None,
        "records": [dict(row) for row in records],
    }


@app.route("/")
def index():
    role = current_user_role()
    if role == "teacher":
        return redirect(url_for("dashboard"))
    if role == "student":
        return redirect(url_for("student_dashboard"))
    return render_template("index.html")


@app.route("/login", methods=["GET", "POST"])
def login():
    return redirect(url_for("teacher_login"))


@app.route("/teacher-login", methods=["GET", "POST"])
def teacher_login():
    if request.method == "POST":
        username = request.form.get("username", "").strip()
        password = request.form.get("password", "")

        conn = get_db_connection()
        admin = conn.execute(
            """
            SELECT id, username, password_hash
            FROM users
            WHERE username = ? AND role = 'teacher'
            """,
            (username,),
        ).fetchone()
        conn.close()

        if admin and check_password_hash(admin["password_hash"], password):
            session.clear()
            session["user_role"] = "teacher"
            session["user_id"] = admin["id"]
            session["display_name"] = admin["username"]
            session["admin_id"] = admin["id"]
            session["admin_username"] = admin["username"]
            return redirect(url_for("dashboard"))

        flash("Invalid username or password.", "error")

    return render_template(
        "login.html",
        login_title="Teacher Login",
        form_action=url_for("teacher_login"),
        username_label="Username",
        username_autocomplete="username",
        alternate_url=url_for("student_login"),
        alternate_text="Student Login",
    )


@app.route("/student-login", methods=["GET", "POST"])
def student_login():
    if request.method == "POST":
        student_id = request.form.get("username", "").strip()
        password = request.form.get("password", "")

        conn = get_db_connection()
        student = conn.execute(
            """
            SELECT student_id, name, password_hash
            FROM students
            WHERE student_id = ?
            """,
            (student_id,),
        ).fetchone()
        conn.close()

        if student and student["password_hash"] and check_password_hash(
            student["password_hash"],
            password,
        ):
            session.clear()
            session["user_role"] = "student"
            session["user_id"] = student["student_id"]
            session["display_name"] = student["name"]
            session["student_id"] = student["student_id"]
            session["student_name"] = student["name"]
            return redirect(url_for("student_dashboard"))

        flash("Invalid student ID or password.", "error")

    return render_template(
        "login.html",
        login_title="Student Login",
        form_action=url_for("student_login"),
        username_label="Student ID",
        username_autocomplete="username",
        alternate_url=url_for("teacher_login"),
        alternate_text="Teacher Login",
    )


@app.route("/logout")
def logout():
    session.clear()
    return redirect(url_for("index"))


@app.route("/dashboard")
@login_required
def dashboard():
    return render_template(
        "dashboard.html",
        admin_username=session.get("admin_username", DEFAULT_TEACHER_USERNAME),
    )


@app.route("/student-dashboard")
@student_login_required
def student_dashboard():
    return render_template(
        "student_dashboard.html",
        student_id=session.get("student_id"),
        student_name=session.get("student_name"),
    )


@app.route("/api/status")
@login_required
def api_status():
    known = active_known_encodings()
    student_ids = {record["student_id"] for record in known}
    return jsonify(
        {
            "success": True,
            "vision_ready": vision_libraries_ready(),
            "trained_images": len(known),
            "trained_students": len(student_ids),
        }
    )


@app.route("/api/students")
@login_required
def api_students():
    conn = get_db_connection()
    rows = conn.execute(
        "SELECT student_id, name, created_at FROM students ORDER BY created_at DESC"
    ).fetchall()
    conn.close()
    return jsonify({"success": True, "students": [dict(row) for row in rows]})


@app.route("/api/students/<student_id>", methods=["DELETE"])
@login_required
def api_delete_student(student_id):
    try:
        payload = request.get_json(silent=True) or {}
        route_student_id = str(student_id).strip()
        body_student_id = str(payload.get("student_id", "")).strip()
        student_id = route_student_id

        if not validate_student_id(student_id) and validate_student_id(body_student_id):
            student_id = body_student_id

        if not validate_student_id(student_id):
            return jsonify({"success": False, "message": "Invalid student ID."}), 400

        conn = get_db_connection()
        try:
            student = conn.execute(
                "SELECT student_id, name FROM students WHERE student_id = ?", (student_id,)
            ).fetchone()

            if student is None and body_student_id != student_id and validate_student_id(body_student_id):
                student = conn.execute(
                    "SELECT student_id, name FROM students WHERE student_id = ?",
                    (body_student_id,),
                ).fetchone()
                if student is not None:
                    student_id = body_student_id

            if student is None:
                return jsonify({"success": False, "message": "Student not found in the database."}), 404

            student_name = student["name"]
            conn.execute("DELETE FROM attendance WHERE student_id = ?", (student_id,))
            deleted_students = conn.execute(
                "DELETE FROM students WHERE student_id = ?", (student_id,)
            ).rowcount

            if deleted_students != 1:
                conn.rollback()
                return jsonify({"success": False, "message": "Student was not deleted from the database."}), 409

            conn.commit()
        finally:
            conn.close()

        cleanup_warnings = []
        try:
            removed_encodings = remove_student_encodings(student_id)
        except Exception:
            app.logger.exception("Could not update saved face encodings for student %s.", student_id)
            removed_encodings = 0
            cleanup_warnings.append("trained face data could not be updated")

        try:
            removed_folder = remove_student_folder(student_id)
        except Exception:
            app.logger.exception("Could not remove saved face images for student %s.", student_id)
            removed_folder = False
            cleanup_warnings.append("saved face image folder could not be removed")

        cleanup_note = ""
        if cleanup_warnings:
            cleanup_note = f" Cleanup warning: {', '.join(cleanup_warnings)}."

        return jsonify(
            {
                "success": True,
                "message": f"Deleted {student_name} and removed their database records.{cleanup_note}",
                "removed_encodings": removed_encodings,
                "removed_face_images": removed_folder,
            }
        )
    except Exception:
        app.logger.exception("Student deletion failed.")
        return (
            jsonify(
                {
                    "success": False,
                    "message": "Student could not be deleted. Please refresh the dashboard and try again.",
                }
            ),
            500,
        )


@app.route("/api/register-student", methods=["POST"])
@login_required
def api_register_student():
    if not vision_libraries_ready():
        return vision_error_response()

    payload = request.get_json(silent=True) or {}
    student_id = str(payload.get("student_id", "")).strip()
    name = str(payload.get("name", "")).strip()
    password = str(payload.get("password", "")).strip()
    images = payload.get("images", [])

    if not validate_student_id(student_id):
        return jsonify({"success": False, "message": "Use only letters, numbers, dash, or underscore for Student ID."}), 400

    if len(name) < 2:
        return jsonify({"success": False, "message": "Student name is required."}), 400

    if len(password) < 4:
        return jsonify({"success": False, "message": "Student login password must be at least 4 characters."}), 400

    if not isinstance(images, list) or len(images) < MIN_REGISTRATION_IMAGES:
        return jsonify({"success": False, "message": f"Capture at least {MIN_REGISTRATION_IMAGES} face images."}), 400

    images_to_process = images[:MAX_REGISTRATION_IMAGES]

    conn = get_db_connection()
    existing = conn.execute(
        "SELECT student_id FROM students WHERE student_id = ?", (student_id,)
    ).fetchone()
    conn.close()
    if existing:
        return jsonify({"success": False, "message": "Student ID already exists."}), 409

    folder = student_folder(student_id)
    folder.mkdir(parents=True, exist_ok=True)

    new_records = []
    saved_images = 0
    skipped_images = 0
    processed_images = 0
    face_detections = 0
    fallback_images = []

    for index, image_data in enumerate(images_to_process, start=1):
        processed_images += 1
        try:
            image_bgr = decode_image_from_data_url(image_data)
            image_path = folder / f"{student_id}_{index:02d}.jpg"
            cv2.imwrite(
                str(image_path),
                image_bgr,
                [int(cv2.IMWRITE_JPEG_QUALITY), REGISTRATION_JPEG_QUALITY],
            )
            saved_images += 1

            face_boxes = detect_faces(
                image_bgr,
                thorough=False,
                max_width=REGISTRATION_DETECTION_WIDTH,
            )
            face_detections += len(face_boxes)

            encoding, _ = best_face_encoding(image_bgr, face_boxes, run_fallback=False)
            if encoding is None:
                fallback_images.append(image_bgr)
                skipped_images += 1
                continue

            new_records.append(
                {
                    "student_id": student_id,
                    "name": name,
                    "encoding": encoding,
                }
            )
            if len(new_records) >= MIN_REGISTRATION_IMAGES:
                break
        except Exception:
            skipped_images += 1

    if len(new_records) < MIN_REGISTRATION_IMAGES:
        remaining_samples = MIN_REGISTRATION_IMAGES - len(new_records)
        for image_bgr in fallback_images[:remaining_samples]:
            try:
                face_boxes = detect_faces(image_bgr, thorough=True)
                face_detections += len(face_boxes)
                encoding, _ = best_face_encoding(image_bgr, face_boxes)
                if encoding is None:
                    continue

                new_records.append(
                    {
                        "student_id": student_id,
                        "name": name,
                        "encoding": encoding,
                    }
                )
                if len(new_records) >= MIN_REGISTRATION_IMAGES:
                    break
            except Exception:
                continue

    skipped_images = max(0, processed_images - len(new_records))

    if not new_records:
        try:
            remove_student_folder(student_id)
        except Exception:
            app.logger.warning("Could not remove failed registration images for %s.", student_id)
        return (
            jsonify(
                {
                    "success": False,
                    "message": (
                        "No usable face encoding was created. Keep only one face in "
                        "the frame, face the camera directly, and capture 3-5 images "
                        "from slightly different angles."
                    ),
                    "saved_images": saved_images,
                    "skipped_images": skipped_images,
                    "face_detections": face_detections,
                }
            ),
            400,
        )

    conn = get_db_connection()
    conn.execute(
        """
        INSERT INTO students (student_id, name, password_hash, created_at)
        VALUES (?, ?, ?, ?)
        """,
        (
            student_id,
            name,
            generate_password_hash(password),
            datetime.now().isoformat(timespec="seconds"),
        ),
    )
    conn.commit()
    conn.close()

    known_records = load_known_encodings()
    known_records.extend(new_records)
    save_known_encodings(known_records)

    return jsonify(
        {
            "success": True,
            "message": f"Registered {name} with {len(new_records)} trained face samples.",
            "saved_images": saved_images,
            "trained_images": len(new_records),
            "skipped_images": skipped_images,
        }
    )


@app.route("/api/retrain", methods=["POST"])
@login_required
def api_retrain():
    if not vision_libraries_ready():
        return vision_error_response()

    result = rebuild_encodings_from_dataset()
    return jsonify(
        {
            "success": True,
            "message": "Training completed.",
            "trained_images": result["trained"],
            "skipped_images": result["skipped"],
        }
    )


@app.route("/api/recognize", methods=["POST"])
@any_login_required
def api_recognize():
    if not vision_libraries_ready():
        return vision_error_response()

    known_records = active_known_encodings()
    if current_user_role() == "student":
        student_id = session.get("student_id")
        known_records = [
            record for record in known_records if record["student_id"] == student_id
        ]

    if not known_records:
        message = (
            "No trained face data found for your student profile."
            if current_user_role() == "student"
            else "No trained face data found. Register a student first."
        )
        return jsonify(
            {
                "success": False,
                "message": message,
                "faces": [],
            }
        ), 400

    payload = request.get_json(silent=True) or {}
    image_data = payload.get("image")
    if not image_data:
        return jsonify({"success": False, "message": "Image frame is required."}), 400

    try:
        image_bgr = decode_image_from_data_url(image_data)
    except Exception:
        return jsonify({"success": False, "message": "Invalid image frame."}), 400

    face_boxes = detect_faces(image_bgr)
    if not face_boxes:
        return jsonify({"success": True, "message": "No face detected.", "faces": []})

    known_encodings = [record["encoding"] for record in known_records]
    faces = []

    for face_box in face_boxes:
        unknown_encoding = encode_face(image_bgr, face_box)
        if unknown_encoding is None:
            continue

        distances = face_recognition.face_distance(known_encodings, unknown_encoding)
        best_index = int(np.argmin(distances))
        best_distance = float(distances[best_index])

        face_payload = {
            "box": face_box_to_api(face_box),
            "name": "Unknown",
            "student_id": None,
            "confidence": round(max(0.0, 1.0 - best_distance), 3),
            "status": "unknown",
            "message": "Face not recognized.",
        }

        if best_distance <= 0.5:
            matched = known_records[best_index]
            attendance = mark_attendance(matched["student_id"], matched["name"])
            face_payload.update(
                {
                    "name": matched["name"],
                    "student_id": matched["student_id"],
                    "status": "marked" if attendance.get("marked") else "duplicate",
                    "message": (
                        "Attendance marked."
                        if attendance.get("marked")
                        else "Attendance already marked today."
                    ),
                    "date": attendance["date"],
                    "time": attendance["time"],
                }
            )

        faces.append(face_payload)

    return jsonify({"success": True, "faces": faces})


@app.route("/api/attendance")
@login_required
def api_attendance():
    query, params = attendance_query(request.args)
    conn = get_db_connection()
    rows = conn.execute(query, params).fetchall()
    conn.close()
    return jsonify({"success": True, "records": [dict(row) for row in rows]})


@app.route("/api/student/summary")
@student_login_required
def api_student_summary():
    summary = student_attendance_summary(session.get("student_id"))
    if summary is None:
        return jsonify({"success": False, "message": "Student profile not found."}), 404
    return jsonify({"success": True, **summary})


@app.route("/api/export")
@login_required
def api_export():
    query, params = attendance_query(request.args)
    conn = get_db_connection()

    if pd is not None:
        csv_text = pd.read_sql_query(query, conn, params=params).to_csv(index=False)
    else:
        rows = conn.execute(query, params).fetchall()
        output = io.StringIO()
        output.write("id,student_id,name,date,time\n")
        for row in rows:
            values = [row["id"], row["student_id"], row["name"], row["date"], row["time"]]
            output.write(",".join(f'"{str(value).replace(chr(34), chr(34) + chr(34))}"' for value in values))
            output.write("\n")
        csv_text = output.getvalue()

    conn.close()
    filename = f"attendance_{datetime.now().strftime('%Y%m%d_%H%M%S')}.csv"
    return Response(
        csv_text,
        mimetype="text/csv",
        headers={"Content-Disposition": f"attachment; filename={filename}"},
    )


init_database()


if __name__ == "__main__":
    app.run(debug=True, use_reloader=False)
