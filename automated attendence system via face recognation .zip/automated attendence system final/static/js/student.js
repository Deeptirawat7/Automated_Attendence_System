const state = {
    stream: null,
    attendanceTimer: null,
    recognitionBusy: false,
    recentLogs: new Map(),
};

const elements = {};

document.addEventListener("DOMContentLoaded", () => {
    cacheElements();
    restoreTheme();
    bindNavigation();
    bindAttendance();
    bindSummary();
    loadStudentSummary();
});

function cacheElements() {
    elements.navLinks = document.querySelectorAll(".nav-link");
    elements.sections = document.querySelectorAll(".dashboard-section");
    elements.darkModeToggle = document.getElementById("darkModeToggle");
    elements.toast = document.getElementById("toast");

    elements.attendanceVideo = document.getElementById("studentAttendanceVideo");
    elements.attendanceOverlay = document.getElementById("studentAttendanceOverlay");
    elements.startAttendanceCamera = document.getElementById("startStudentAttendanceCamera");
    elements.stopAttendanceCamera = document.getElementById("stopStudentAttendanceCamera");
    elements.attendanceState = document.getElementById("studentAttendanceState");
    elements.recognitionLog = document.getElementById("studentRecognitionLog");

    elements.attendancePercentage = document.getElementById("attendancePercentage");
    elements.presentDays = document.getElementById("presentDays");
    elements.totalDays = document.getElementById("totalDays");
    elements.todayStatus = document.getElementById("todayStatus");
    elements.refreshSummary = document.getElementById("refreshStudentSummary");
    elements.attendanceTableBody = document.getElementById("studentAttendanceTableBody");
}

function restoreTheme() {
    const savedTheme = localStorage.getItem("attendance-theme");
    const dark = savedTheme === "dark";
    document.documentElement.dataset.theme = dark ? "dark" : "light";
    elements.darkModeToggle.checked = dark;

    elements.darkModeToggle.addEventListener("change", () => {
        const nextTheme = elements.darkModeToggle.checked ? "dark" : "light";
        document.documentElement.dataset.theme = nextTheme;
        localStorage.setItem("attendance-theme", nextTheme);
    });
}

function bindNavigation() {
    elements.navLinks.forEach((button) => {
        button.addEventListener("click", () => {
            const section = button.dataset.section;
            showSection(section);
            stopCamera();
        });
    });
}

function showSection(sectionName) {
    elements.navLinks.forEach((button) => {
        button.classList.toggle("active", button.dataset.section === sectionName);
    });

    elements.sections.forEach((section) => {
        section.classList.toggle("active", section.id === `${sectionName}Section`);
    });
}

function bindAttendance() {
    elements.startAttendanceCamera.addEventListener("click", async () => {
        try {
            await startCamera();
            elements.attendanceState.textContent = "Scanning";
            showToast("Attendance camera started.");
            state.attendanceTimer = window.setInterval(recognizeAttendanceFrame, 1400);
            recognizeAttendanceFrame();
        } catch (error) {
            showToast(error.message);
        }
    });

    elements.stopAttendanceCamera.addEventListener("click", () => {
        stopCamera();
        showToast("Attendance camera stopped.");
    });
}

function bindSummary() {
    elements.refreshSummary.addEventListener("click", loadStudentSummary);
}

async function apiJson(url, options = {}) {
    const response = await fetch(url, {
        headers: { "Content-Type": "application/json" },
        ...options,
    });
    const data = await response.json().catch(() => ({
        success: false,
        message: "Server returned an unreadable response.",
    }));

    if (!response.ok || data.success === false) {
        throw new Error(data.message || "Request failed.");
    }

    return data;
}

async function startCamera() {
    if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
        throw new Error("Camera access is not supported in this browser.");
    }

    stopCamera();

    const stream = await navigator.mediaDevices.getUserMedia({
        video: {
            width: { ideal: 960 },
            height: { ideal: 720 },
            facingMode: "user",
        },
        audio: false,
    });

    state.stream = stream;
    elements.attendanceVideo.srcObject = stream;
    await elements.attendanceVideo.play();
    resizeOverlay();
}

function stopCamera() {
    if (state.attendanceTimer) {
        window.clearInterval(state.attendanceTimer);
        state.attendanceTimer = null;
    }

    if (state.stream) {
        state.stream.getTracks().forEach((track) => track.stop());
    }

    elements.attendanceVideo.srcObject = null;
    state.stream = null;
    state.recognitionBusy = false;
    clearOverlay();
    elements.attendanceState.textContent = "Idle";
}

function captureFrame() {
    const video = elements.attendanceVideo;
    if (!video.srcObject || video.readyState < 2) {
        throw new Error("Start the camera before capturing.");
    }

    const canvas = document.createElement("canvas");
    canvas.width = video.videoWidth || 640;
    canvas.height = video.videoHeight || 480;
    const context = canvas.getContext("2d");
    context.drawImage(video, 0, 0, canvas.width, canvas.height);
    return canvas.toDataURL("image/jpeg", 0.86);
}

async function recognizeAttendanceFrame() {
    if (state.recognitionBusy || !state.stream) {
        return;
    }

    state.recognitionBusy = true;
    try {
        const frame = captureFrame();
        const result = await apiJson("/api/recognize", {
            method: "POST",
            body: JSON.stringify({ image: frame }),
        });

        const faces = result.faces || [];
        drawFaces(faces);
        renderRecognitionEvents(faces);

        if (faces.some((face) => face.status === "marked" || face.status === "duplicate")) {
            playBeep();
            await loadStudentSummary();
        }
    } catch (error) {
        elements.attendanceState.textContent = "Paused";
        showToast(error.message);
        stopCamera();
    } finally {
        state.recognitionBusy = false;
    }
}

function renderRecognitionEvents(faces) {
    if (!faces.length) {
        elements.attendanceState.textContent = "Scanning";
        return;
    }

    faces.forEach((face) => {
        const key = `${face.status}-${face.student_id || "unknown"}-${face.name}`;
        const now = Date.now();
        const lastLogged = state.recentLogs.get(key) || 0;
        if (now - lastLogged < 4500) {
            return;
        }
        state.recentLogs.set(key, now);
        addRecognitionLog(face);

        if (face.status === "marked") {
            showToast(`Attendance marked at ${face.time}.`);
        }
        if (face.status === "duplicate") {
            showToast("Attendance already marked today.");
        }
    });
}

function addRecognitionLog(face) {
    const empty = elements.recognitionLog.querySelector(".muted");
    if (empty) {
        empty.remove();
    }

    const item = document.createElement("div");
    item.className = `log-item ${face.status}`;

    const name = document.createElement("strong");
    name.textContent = face.student_id ? `${face.name} (${face.student_id})` : face.name;

    const detail = document.createElement("span");
    detail.textContent = face.time ? `${face.message} ${face.date} ${face.time}` : face.message;

    item.append(name, detail);
    elements.recognitionLog.prepend(item);

    while (elements.recognitionLog.children.length > 8) {
        elements.recognitionLog.lastElementChild.remove();
    }
}

function resizeOverlay() {
    elements.attendanceOverlay.width = elements.attendanceVideo.videoWidth || 640;
    elements.attendanceOverlay.height = elements.attendanceVideo.videoHeight || 480;
}

function clearOverlay() {
    const context = elements.attendanceOverlay.getContext("2d");
    context.clearRect(0, 0, elements.attendanceOverlay.width, elements.attendanceOverlay.height);
}

function drawFaces(faces) {
    resizeOverlay();
    const context = elements.attendanceOverlay.getContext("2d");
    context.clearRect(0, 0, elements.attendanceOverlay.width, elements.attendanceOverlay.height);
    context.lineWidth = 4;
    context.font = "16px system-ui, sans-serif";

    faces.forEach((face) => {
        const box = face.box;
        const color = face.status === "marked"
            ? "#238257"
            : face.status === "duplicate"
                ? "#af6b17"
                : "#b83535";
        const label = face.student_id ? `${face.name} - ${face.status}` : "Unknown";

        context.strokeStyle = color;
        context.fillStyle = color;
        context.strokeRect(box.left, box.top, box.width, box.height);

        const textWidth = context.measureText(label).width + 16;
        const labelY = Math.max(0, box.top - 30);
        context.fillRect(box.left, labelY, textWidth, 28);
        context.fillStyle = "#ffffff";
        context.fillText(label, box.left + 8, labelY + 19);
    });
}

async function loadStudentSummary() {
    try {
        const data = await apiJson("/api/student/summary");
        elements.attendancePercentage.textContent = `${data.percentage}%`;
        elements.presentDays.textContent = data.present_days;
        elements.totalDays.textContent = data.total_days;
        elements.todayStatus.textContent = data.today_marked ? "Marked" : "Not Marked";
        renderAttendanceRecords(data.records || []);
    } catch (error) {
        showToast(error.message);
    }
}

function renderAttendanceRecords(records) {
    elements.attendanceTableBody.innerHTML = "";

    if (!records.length) {
        elements.attendanceTableBody.innerHTML = '<tr><td colspan="4">No attendance marked yet.</td></tr>';
        return;
    }

    records.forEach((record, index) => {
        const row = document.createElement("tr");
        [index + 1, record.date, record.time, "Present"].forEach((value) => {
            const cell = document.createElement("td");
            cell.textContent = value;
            row.appendChild(cell);
        });
        elements.attendanceTableBody.appendChild(row);
    });
}

function showToast(message) {
    elements.toast.textContent = message;
    elements.toast.classList.add("show");
    window.clearTimeout(elements.toastTimer);
    elements.toastTimer = window.setTimeout(() => {
        elements.toast.classList.remove("show");
    }, 3000);
}

function playBeep() {
    const AudioContext = window.AudioContext || window.webkitAudioContext;
    if (!AudioContext) {
        return;
    }

    const audio = new AudioContext();
    const oscillator = audio.createOscillator();
    const gain = audio.createGain();

    oscillator.type = "sine";
    oscillator.frequency.value = 880;
    gain.gain.setValueAtTime(0.0001, audio.currentTime);
    gain.gain.exponentialRampToValueAtTime(0.16, audio.currentTime + 0.02);
    gain.gain.exponentialRampToValueAtTime(0.0001, audio.currentTime + 0.18);

    oscillator.connect(gain);
    gain.connect(audio.destination);
    oscillator.start();
    oscillator.stop(audio.currentTime + 0.2);
}
