const state = {
    stream: null,
    currentVideo: null,
    capturedImages: [],
    attendanceTimer: null,
    recognitionBusy: false,
    recentLogs: new Map(),
};

const MIN_CAPTURED_IMAGES = 3;
const MAX_CAPTURED_IMAGES = 5;
const CAPTURE_MAX_SIDE = 640;
const CAPTURE_JPEG_QUALITY = 0.72;

const elements = {};

document.addEventListener("DOMContentLoaded", () => {
    cacheElements();
    restoreTheme();
    bindNavigation();
    bindRegisterStudent();
    bindStudentActions();
    bindAttendance();
    bindRecords();
    bindExport();
    loadDashboardData();
});

function cacheElements() {
    elements.navLinks = document.querySelectorAll(".nav-link");
    elements.sections = document.querySelectorAll(".dashboard-section");
    elements.darkModeToggle = document.getElementById("darkModeToggle");
    elements.toast = document.getElementById("toast");

    elements.studentForm = document.getElementById("studentForm");
    elements.studentId = document.getElementById("studentId");
    elements.studentName = document.getElementById("studentName");
    elements.studentPassword = document.getElementById("studentPassword");
    elements.registerVideo = document.getElementById("registerVideo");
    elements.startRegisterCamera = document.getElementById("startRegisterCamera");
    elements.captureRegisterImage = document.getElementById("captureRegisterImage");
    elements.clearRegisterImages = document.getElementById("clearRegisterImages");
    elements.captureCount = document.getElementById("captureCount");
    elements.captureThumbnails = document.getElementById("captureThumbnails");
    elements.retrainButton = document.getElementById("retrainButton");
    elements.studentsTableBody = document.getElementById("studentsTableBody");

    elements.attendanceVideo = document.getElementById("attendanceVideo");
    elements.attendanceOverlay = document.getElementById("attendanceOverlay");
    elements.startAttendanceCamera = document.getElementById("startAttendanceCamera");
    elements.stopAttendanceCamera = document.getElementById("stopAttendanceCamera");
    elements.attendanceState = document.getElementById("attendanceState");
    elements.recognitionLog = document.getElementById("recognitionLog");

    elements.recordFilters = document.getElementById("recordFilters");
    elements.filterDate = document.getElementById("filterDate");
    elements.filterStudent = document.getElementById("filterStudent");
    elements.clearFilters = document.getElementById("clearFilters");
    elements.attendanceTableBody = document.getElementById("attendanceTableBody");

    elements.exportForm = document.getElementById("exportForm");
    elements.exportDate = document.getElementById("exportDate");
    elements.exportStudent = document.getElementById("exportStudent");

    elements.studentCount = document.getElementById("studentCount");
    elements.trainedCount = document.getElementById("trainedCount");
    elements.todayCount = document.getElementById("todayCount");
    elements.visionStatus = document.getElementById("visionStatus");
}

function restoreTheme() {
    const savedTheme = localStorage.getItem("attendance-theme");
    const dark = savedTheme === "dark";
    document.documentElement.dataset.theme = dark ? "dark" : "light";
    elements.darkModeToggle.checked = dark;

    elements.darkModeToggle.addEventListener("change", () => {
        const nextTheme = elements.darkModeToggle.checked ? "dark" : "light";
        document.documentElement.dataset.theme = nextTheme;
        localStorage.setItem("attendance-theme", nextTheme);
    });
}

function bindNavigation() {
    elements.navLinks.forEach((button) => {
        button.addEventListener("click", () => {
            const section = button.dataset.section;
            showSection(section);
            stopCamera();
        });
    });
}

function showSection(sectionName) {
    elements.navLinks.forEach((button) => {
        button.classList.toggle("active", button.dataset.section === sectionName);
    });

    elements.sections.forEach((section) => {
        section.classList.toggle("active", section.id === `${sectionName}Section`);
    });
}

function bindRegisterStudent() {
    elements.startRegisterCamera.addEventListener("click", async () => {
        try {
            await startCamera(elements.registerVideo);
            showToast("Registration camera started.");
        } catch (error) {
            showToast(error.message);
        }
    });

    elements.captureRegisterImage.addEventListener("click", () => {
        try {
            if (state.capturedImages.length >= MAX_CAPTURED_IMAGES) {
                showToast(`Use up to ${MAX_CAPTURED_IMAGES} images for faster registration.`);
                return;
            }

            const frame = captureFrame(elements.registerVideo);
            state.capturedImages.push(frame);
            renderCapturedImages();
            showToast("Image captured.");
        } catch (error) {
            showToast(error.message);
        }
    });

    elements.clearRegisterImages.addEventListener("click", () => {
        state.capturedImages = [];
        renderCapturedImages();
    });

    elements.studentForm.addEventListener("submit", async (event) => {
        event.preventDefault();

        if (state.capturedImages.length < MIN_CAPTURED_IMAGES) {
            showToast(`Capture at least ${MIN_CAPTURED_IMAGES} images.`);
            return;
        }

        setFormWorking(elements.studentForm, true);
        try {
            const result = await apiJson("/api/register-student", {
                method: "POST",
                body: JSON.stringify({
                    student_id: elements.studentId.value.trim(),
                    name: elements.studentName.value.trim(),
                    password: elements.studentPassword.value.trim(),
                    images: state.capturedImages,
                }),
            });

            showToast(result.message);
            elements.studentForm.reset();
            state.capturedImages = [];
            renderCapturedImages();
            await loadDashboardData();
        } catch (error) {
            showToast(error.message);
        } finally {
            setFormWorking(elements.studentForm, false);
        }
    });

    elements.retrainButton.addEventListener("click", async () => {
        elements.retrainButton.disabled = true;
        try {
            const result = await apiJson("/api/retrain", { method: "POST" });
            showToast(`${result.message} ${result.trained_images} image samples trained.`);
            await loadStatus();
        } catch (error) {
            showToast(error.message);
        } finally {
            elements.retrainButton.disabled = false;
        }
    });
}

function bindStudentActions() {
    elements.studentsTableBody.addEventListener("click", async (event) => {
        const button = event.target.closest("[data-delete-student]");
        if (!button) {
            return;
        }

        const studentId = button.dataset.deleteStudent;
        const studentName = button.dataset.studentName || studentId;
        const confirmed = window.confirm(
            `Delete ${studentName} (${studentId})? This will remove their attendance records and face data.`
        );

        if (!confirmed) {
            return;
        }

        button.disabled = true;
        try {
            const result = await apiJson(`/api/students/${encodeURIComponent(studentId)}`, {
                method: "DELETE",
                body: JSON.stringify({ student_id: studentId }),
            });
            showToast(result.message);
            await loadDashboardData();
        } catch (error) {
            button.disabled = false;
            if (error.status === 404) {
                await loadDashboardData();
            }
            showToast(`Could not delete student. ${error.message}`);
        }
    });
}

function bindAttendance() {
    elements.startAttendanceCamera.addEventListener("click", async () => {
        try {
            await startCamera(elements.attendanceVideo, elements.attendanceOverlay);
            elements.attendanceState.textContent = "Scanning";
            showToast("Attendance camera started.");
            state.attendanceTimer = window.setInterval(recognizeAttendanceFrame, 1400);
            recognizeAttendanceFrame();
        } catch (error) {
            showToast(error.message);
        }
    });

    elements.stopAttendanceCamera.addEventListener("click", () => {
        stopCamera();
        showToast("Attendance camera stopped.");
    });
}

function bindRecords() {
    elements.recordFilters.addEventListener("submit", async (event) => {
        event.preventDefault();
        await loadAttendanceRecords();
    });

    elements.clearFilters.addEventListener("click", async () => {
        elements.filterDate.value = "";
        elements.filterStudent.value = "";
        await loadAttendanceRecords();
    });
}

function bindExport() {
    elements.exportForm.addEventListener("submit", (event) => {
        event.preventDefault();
        const params = new URLSearchParams();
        if (elements.exportDate.value) {
            params.set("date", elements.exportDate.value);
        }
        if (elements.exportStudent.value.trim()) {
            params.set("student", elements.exportStudent.value.trim());
        }
        window.location.href = `/api/export?${params.toString()}`;
    });
}

async function loadDashboardData() {
    await Promise.all([loadStudents(), loadStatus(), loadAttendanceRecords(), loadTodayCount()]);
}

async function apiJson(url, options = {}) {
    const response = await fetch(url, {
        headers: { "Content-Type": "application/json" },
        ...options,
    });

    const bodyText = await response.text();
    let data = null;
    if (bodyText) {
        try {
            data = JSON.parse(bodyText);
        } catch (error) {
            data = null;
        }
    }

    if (!response.ok) {
        const statusText = response.statusText || "Error";
        const fallbackMessage = `Request failed (${response.status} ${statusText}).`;
        const error = new Error((data && data.message) || readableResponseText(bodyText) || fallbackMessage);
        error.status = response.status;
        throw error;
    }

    if (!data) {
        throw new Error("Server response was not in the expected JSON format.");
    }

    if (data.success === false) {
        throw new Error(data.message || "Request failed.");
    }

    return data;
}

function readableResponseText(text) {
    if (!text) {
        return "";
    }

    const cleaned = text
        .replace(/<script[\s\S]*?<\/script>/gi, "")
        .replace(/<style[\s\S]*?<\/style>/gi, "")
        .replace(/<[^>]*>/g, " ")
        .replace(/\s+/g, " ")
        .trim();

    if (!cleaned) {
        return "";
    }

    return cleaned.length > 180 ? `${cleaned.slice(0, 177)}...` : cleaned;
}

async function startCamera(videoElement, overlayElement = null) {
    if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
        throw new Error("Camera access is not supported in this browser.");
    }

    stopCamera();

    const stream = await navigator.mediaDevices.getUserMedia({
        video: {
            width: { ideal: 960 },
            height: { ideal: 720 },
            facingMode: "user",
        },
        audio: false,
    });

    state.stream = stream;
    state.currentVideo = videoElement;
    videoElement.srcObject = stream;
    await videoElement.play();

    if (overlayElement) {
        resizeOverlay(videoElement, overlayElement);
    }
}

function stopCamera() {
    if (state.attendanceTimer) {
        window.clearInterval(state.attendanceTimer);
        state.attendanceTimer = null;
    }

    if (state.stream) {
        state.stream.getTracks().forEach((track) => track.stop());
    }

    if (state.currentVideo) {
        state.currentVideo.srcObject = null;
    }

    state.stream = null;
    state.currentVideo = null;
    state.recognitionBusy = false;
    clearOverlay();
    if (elements.attendanceState) {
        elements.attendanceState.textContent = "Idle";
    }
}

function captureFrame(videoElement) {
    if (!videoElement.srcObject || videoElement.readyState < 2) {
        throw new Error("Start the camera before capturing.");
    }

    const canvas = document.createElement("canvas");
    const sourceWidth = videoElement.videoWidth || 640;
    const sourceHeight = videoElement.videoHeight || 480;
    const scale = Math.min(1, CAPTURE_MAX_SIDE / Math.max(sourceWidth, sourceHeight));
    canvas.width = Math.round(sourceWidth * scale);
    canvas.height = Math.round(sourceHeight * scale);
    const context = canvas.getContext("2d");
    context.drawImage(videoElement, 0, 0, canvas.width, canvas.height);
    return canvas.toDataURL("image/jpeg", CAPTURE_JPEG_QUALITY);
}

function renderCapturedImages() {
    elements.captureCount.textContent = state.capturedImages.length;
    elements.captureThumbnails.innerHTML = "";

    state.capturedImages.forEach((image) => {
        const thumbnail = document.createElement("img");
        thumbnail.src = image;
        thumbnail.alt = "Captured student face";
        elements.captureThumbnails.appendChild(thumbnail);
    });
}

async function recognizeAttendanceFrame() {
    if (state.recognitionBusy || state.currentVideo !== elements.attendanceVideo) {
        return;
    }

    state.recognitionBusy = true;
    try {
        const frame = captureFrame(elements.attendanceVideo);
        const result = await apiJson("/api/recognize", {
            method: "POST",
            body: JSON.stringify({ image: frame }),
        });

        drawFaces(result.faces || []);
        renderRecognitionEvents(result.faces || []);

        if ((result.faces || []).some((face) => face.status === "marked")) {
            playBeep();
            await Promise.all([loadAttendanceRecords(), loadTodayCount()]);
        }
    } catch (error) {
        elements.attendanceState.textContent = "Paused";
        showToast(error.message);
        stopCamera();
    } finally {
        state.recognitionBusy = false;
    }
}

function renderRecognitionEvents(faces) {
    if (!faces.length) {
        elements.attendanceState.textContent = "Scanning";
        return;
    }

    faces.forEach((face) => {
        const key = `${face.status}-${face.student_id || "unknown"}-${face.name}`;
        const now = Date.now();
        const lastLogged = state.recentLogs.get(key) || 0;
        if (now - lastLogged < 4500) {
            return;
        }
        state.recentLogs.set(key, now);
        addRecognitionLog(face);

        if (face.status === "marked") {
            showToast(`${face.name} marked at ${face.time}.`);
        }
    });
}

function addRecognitionLog(face) {
    const empty = elements.recognitionLog.querySelector(".muted");
    if (empty) {
        empty.remove();
    }

    const item = document.createElement("div");
    item.className = `log-item ${face.status}`;

    const name = document.createElement("strong");
    name.textContent = face.student_id ? `${face.name} (${face.student_id})` : face.name;

    const detail = document.createElement("span");
    detail.textContent = face.time ? `${face.message} ${face.date} ${face.time}` : face.message;

    item.append(name, detail);
    elements.recognitionLog.prepend(item);

    while (elements.recognitionLog.children.length > 8) {
        elements.recognitionLog.lastElementChild.remove();
    }
}

function resizeOverlay(videoElement, overlayElement) {
    overlayElement.width = videoElement.videoWidth || 640;
    overlayElement.height = videoElement.videoHeight || 480;
}

function clearOverlay() {
    const overlay = elements.attendanceOverlay;
    if (!overlay) {
        return;
    }
    const context = overlay.getContext("2d");
    context.clearRect(0, 0, overlay.width, overlay.height);
}

function drawFaces(faces) {
    const overlay = elements.attendanceOverlay;
    const video = elements.attendanceVideo;
    resizeOverlay(video, overlay);

    const context = overlay.getContext("2d");
    context.clearRect(0, 0, overlay.width, overlay.height);
    context.lineWidth = 4;
    context.font = "16px system-ui, sans-serif";

    faces.forEach((face) => {
        const box = face.box;
        const color = face.status === "marked"
            ? "#238257"
            : face.status === "duplicate"
                ? "#af6b17"
                : "#b83535";
        const label = face.student_id ? `${face.name} - ${face.status}` : "Unknown";

        context.strokeStyle = color;
        context.fillStyle = color;
        context.strokeRect(box.left, box.top, box.width, box.height);

        const textWidth = context.measureText(label).width + 16;
        const labelY = Math.max(0, box.top - 30);
        context.fillRect(box.left, labelY, textWidth, 28);
        context.fillStyle = "#ffffff";
        context.fillText(label, box.left + 8, labelY + 19);
    });
}

async function loadStudents() {
    try {
        const data = await apiJson("/api/students");
        elements.studentCount.textContent = data.students.length;
        renderStudents(data.students);
    } catch (error) {
        showToast(error.message);
    }
}

function renderStudents(students) {
    elements.studentsTableBody.innerHTML = "";

    if (!students.length) {
        elements.studentsTableBody.innerHTML = '<tr><td colspan="4">No students yet.</td></tr>';
        return;
    }

    students.forEach((student) => {
        const row = document.createElement("tr");
        [student.student_id, student.name, formatDate(student.created_at)].forEach((value) => {
            const cell = document.createElement("td");
            cell.textContent = value;
            row.appendChild(cell);
        });

        const actionCell = document.createElement("td");
        actionCell.className = "table-action-cell";

        const deleteButton = document.createElement("button");
        deleteButton.className = "ghost-button danger-button compact-button";
        deleteButton.type = "button";
        deleteButton.dataset.deleteStudent = student.student_id;
        deleteButton.dataset.studentName = student.name;
        deleteButton.textContent = "Delete";

        actionCell.appendChild(deleteButton);
        row.appendChild(actionCell);
        elements.studentsTableBody.appendChild(row);
    });
}

async function loadStatus() {
    try {
        const data = await apiJson("/api/status");
        elements.trainedCount.textContent = data.trained_images;
        elements.visionStatus.textContent = data.vision_ready ? "Ready" : "Missing";
    } catch (error) {
        elements.visionStatus.textContent = "Missing";
    }
}

async function loadAttendanceRecords() {
    const params = new URLSearchParams();
    if (elements.filterDate.value) {
        params.set("date", elements.filterDate.value);
    }
    if (elements.filterStudent.value.trim()) {
        params.set("student", elements.filterStudent.value.trim());
    }

    try {
        const data = await apiJson(`/api/attendance?${params.toString()}`);
        renderAttendanceRecords(data.records);
    } catch (error) {
        showToast(error.message);
    }
}

async function loadTodayCount() {
    const today = localDateISO();
    try {
        const data = await apiJson(`/api/attendance?date=${today}`);
        elements.todayCount.textContent = data.records.length;
    } catch (error) {
        elements.todayCount.textContent = "0";
    }
}

function renderAttendanceRecords(records) {
    elements.attendanceTableBody.innerHTML = "";

    if (!records.length) {
        elements.attendanceTableBody.innerHTML = '<tr><td colspan="5">No records found.</td></tr>';
        return;
    }

    records.forEach((record, index) => {
        const row = document.createElement("tr");
        [index + 1, record.student_id, record.name, record.date, record.time].forEach((value) => {
            const cell = document.createElement("td");
            cell.textContent = value;
            row.appendChild(cell);
        });
        elements.attendanceTableBody.appendChild(row);
    });
}

function setFormWorking(form, disabled) {
    form.querySelectorAll("button, input").forEach((control) => {
        control.disabled = disabled;
    });
}

function formatDate(value) {
    if (!value) {
        return "";
    }
    return value.split("T")[0];
}

function localDateISO(date = new Date()) {
    const timezoneOffset = date.getTimezoneOffset() * 60000;
    return new Date(date.getTime() - timezoneOffset).toISOString().slice(0, 10);
}

function showToast(message) {
    elements.toast.textContent = message;
    elements.toast.classList.add("show");
    window.clearTimeout(elements.toastTimer);
    elements.toastTimer = window.setTimeout(() => {
        elements.toast.classList.remove("show");
    }, 3000);
}

function playBeep() {
    const AudioContext = window.AudioContext || window.webkitAudioContext;
    if (!AudioContext) {
        return;
    }

    const audio = new AudioContext();
    const oscillator = audio.createOscillator();
    const gain = audio.createGain();

    oscillator.type = "sine";
    oscillator.frequency.value = 880;
    gain.gain.setValueAtTime(0.0001, audio.currentTime);
    gain.gain.exponentialRampToValueAtTime(0.16, audio.currentTime + 0.02);
    gain.gain.exponentialRampToValueAtTime(0.0001, audio.currentTime + 0.18);

    oscillator.connect(gain);
    gain.connect(audio.destination);
    oscillator.start();
    oscillator.stop(audio.currentTime + 0.2);
}
