-- SQLite database script for Automated Attendance System using Face Recognition
-- Default teacher login:
-- Username: admin
-- Password: admin123

PRAGMA foreign_keys = ON;

CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username TEXT UNIQUE NOT NULL,
    password_hash TEXT NOT NULL,
    role TEXT NOT NULL DEFAULT 'teacher'
);

CREATE TABLE IF NOT EXISTS students (
    student_id TEXT PRIMARY KEY,
    name TEXT NOT NULL,
    password_hash TEXT,
    created_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS attendance (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    student_id TEXT NOT NULL,
    name TEXT NOT NULL,
    date TEXT NOT NULL,
    time TEXT NOT NULL,
    created_at TEXT NOT NULL,
    UNIQUE(student_id, date)
);

-- Werkzeug-compatible password hash for "admin123".
INSERT OR IGNORE INTO users (username, password_hash, role)
VALUES (
    'admin',
    'scrypt:32768:8:1$MtwjaKTGFTO2G10s$4503232c6655b8402601800c4e491ce988e8f8eb9b0f49a668273f0ac3cf2698b44a643a33b0387b7ded9bb55cc877d0387ed0590df72646ae69aa7602ae8c91',
    'teacher'
);
